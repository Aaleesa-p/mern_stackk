const express = require('express');
const fs = require('fs');

const path = require('path');
const router = express.Router();

const {Item}=require('../models/product');
const { uuid }= require('uuidv4');  

router.get('/',async (req,res)=>{
    try{
        
        const product = await Item.find();
        return res.status(200).json({
            message:"product fetched sucessfully",
            product
        })
    }
    catch(err){
        return res.status(500).json({
            message: 'Something went wrong.',
            error: err.message
        })
    }
})
 

router.post('/add',async (req, res)=>{
    try{
        
        const {product_name, product_price,product_image, product_description} = req.body;
        if((product_name=='' || product_name==undefined) && error==''){
            error= 'No product name found!';
            
            return res.status(400).json({
                message: error
            })
        }
        if((product_price=='' || product_price==undefined) && error == ''){
            error= 'Product price not found!'
            return res.status(400).json({
                message: error
            })
        }
        if((product_description=='' || product_description==undefined) && error == ''){
            error= 'No product description found!'
             return res.status(400).json({ 
                message: error
            })
        }
    
       
        const productobj={
            product_name,
            product_price,
            product_image,
            product_description
        }
        const product = new Item(productobj);
        await product.save();
        res.status(200).json({
            message:"product saved successfully"
        })
    }
    
    catch(err){
        return res.status(500).json({
            message: 'Something went wrong...',
            error: err.message
        })
    }
})
router.delete("/delete/:id", async (req, res)=>{
    try
    {
        const id=req.params.id;
        const {product_name, product_price,product_image, product_description} = req.body;
            await Item.findByIdAndDelete(id,{product_name, product_price,product_image, product_description});
                return res.status(200).json({
                    message: 'Item deleted successfully',
                    
                })
    }
    
    catch(err){
        console.log(error.message);
        return res.status(500).json({
            message: 'Something went wrong...',
            error: err.message
        })
    }
})
router.put("/update/:id",async (req, res)=>{
    try{
        const id=req.params.id;
        const {product_name,product_price,product_image, product_description}=req.body;
        await Item.findByIdAndUpdate(id,{product_name,product_price,product_image, product_description})
        await product.save();
        if((product_name=='' || product_name==undefined) && error == ''){
                error= 'No product name found!'
                res.status(400).json({
                    message: error
                })
            }
            if((product_price=='' || product_price==undefined) && error == ''){
                error= 'Product price not found!'
                res.status(400).json({
                    message: error
                })
            }
            /* if((product_descrip=='' || product_desc==undefined) && error == ''){
                error= 'No product description found!'
                res.status(400).json({ 
                    message: error
                })
            }*/
           
            else
            return res.status(200).json({
                message:"data updated sucessfully"
            
            })
            
        }

    catch(err){
        return res.status(500).json({
            message: 'Something went wrong...',
            error: err.message
        })
    }
})
module.exports=router