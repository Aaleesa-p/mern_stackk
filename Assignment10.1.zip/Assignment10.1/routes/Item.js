function item(product_id, product_name, product_price,product_image, product_description){
    this.product_id=product_id;
    this.product_name= product_name;
    this.product_price=product_price;
    this.product_image=product_image;
    this.product_description=product_description;
    
    
}
exports.item= item;