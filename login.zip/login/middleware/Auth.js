const jwt = require('jsonwebtoken');

const Auth = async(req,res,next)=>{ //Auth is a middleware
    // console.log(req.headers);
    // console.log(req.body);
    // next();//next function is forwarding the request to the next middleware if any otherwise to that particular route
    try {
        const token = req.headers['x-auth-token'];//accessing the token generated during login,x-auth-token is a property(created by user) of header object 
        if(!token){
            return res.status(400).json({
                message:"Missing auth token"
            })
        }
        if(await jwt.verify(token,'siliconMernCourse')){
            next();
        }
        else{
            return res.status(500).json({
                message:"Unauthorized"
            })
        }
    } catch (err) {
        return res.status(500).json({
            message:"Something went wrong",
            error:err.message
        })
        
    }
}
module.exports = Auth