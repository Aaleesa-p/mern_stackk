const express = require('express');
const { dbconn}=require('./config/db');
const userroutes = require('./routes/user');
const cors = require('cors');

const main = express();

const port = 4000; 

main.use(express.json());
main.use(cors());

main.use('/user',userroutes);
dbconn();
main.listen(port, () =>{
    console.log(`Server started at port${port}`);
})