const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const {User} = require('../models/User');
const router = express.Router();

router.post('/add',async (req,res)=>{
    try{

        let {full_name,email,password} = req.body;

        const salt = await bcrypt.genSalt(10);
        password = await bcrypt.hash(password,salt);

        const userObj = {
            full_name,
            email,
            password,
            confirm_password
        }

        //const user = new User({full_name,email,password});
        const user = new User(userObj);
        await user.save();
        return res.status(200).json({
            message:"User saved successfully",
            user
        })
    }
    catch(err){
        return res.status(500).json({
            message:"Something went wrong"
        }) 
    }
})

router.post('/login',async(req,res)=>{
    try{
        const {email,password} = req.body;
        console.log(email,password);
        const user = await User.findOne({email:email});
        if(user){
            const verifyuser = await bcrypt.compare(password,user.password);
            //bcrypt encrypts the password in the database
            if(verifyuser){
                const payload = {
                    user:{
                        id:user._id ,// here id will behave as payload
                        name:user.full_name
                    }
                }
                const token = jwt.sign(payload,'siliconMernCourse',{expiresIn:3600});
                //siliconMernCourse is called secret key which is required in Auth.js
                res.status(200).json({
                    message:'Logged In',
                    user:{user_id:user._id,email:user.email},
                    token
                })
            }
            else{
                res.status(401).json({
                    message:'Wrong username or password'
                })
            }
        }
        else{
            res.status(401).json({
                message:'Wrong username or password'
            })
        }
    }
    catch(err){
        res.status(400).json({
            message:'Something went wrong'
            
        })
    
    }
})

module.exports = router;